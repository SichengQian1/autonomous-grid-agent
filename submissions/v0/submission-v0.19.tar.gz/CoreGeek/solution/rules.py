from __future__ import annotations

from dataclasses import dataclass


DAY_ROUNDS = 70
NIGHT_ROUNDS = 60
ROUNDS_PER_DAY = DAY_ROUNDS + NIGHT_ROUNDS
NORMAL_TURN_BUDGET_SECONDS = 4.0
WEAPON_BUILD_COST = 25
MAX_WEAPON_COUNT = 3
MAX_WALL_COUNT = 20

TEAM_CHALLENGER = "challenger"
TEAM_DEFENDER = "defender"

ROLE_STATION = "station"
ROLE_GATLING = "gatling"
ROLE_RAILGUN = "railgun"
ROLE_ROCKET = "rocket"
ROLE_WALL = "wall"
ROLE_PIONEER = "pioneer"
ROLE_WORKER = "worker"

HUMAN_ROLE_TYPES = frozenset({ROLE_PIONEER, ROLE_WORKER})
WEAPON_ROLE_TYPES = frozenset({ROLE_GATLING, ROLE_RAILGUN, ROLE_ROCKET})
BUILDING_ROLE_TYPES = frozenset(
    {ROLE_STATION, ROLE_GATLING, ROLE_RAILGUN, ROLE_ROCKET, ROLE_WALL}
)

RESOURCE_ZONE_TYPES = frozenset({"stone", "iron", "copper"})
TASK_POINT_SUFFIX = "TaskPoint"

BUILD_NAMES = frozenset({ROLE_GATLING, ROLE_RAILGUN, ROLE_ROCKET, ROLE_WALL})

TARGETED_USE_ITEMS = frozenset(
    {
        "WallFixer",
        "DizzyWeapon",
        "Bomb",
        "WeaponUpgradeVoucher1",
        "WeaponUpgradeVoucher2",
        "WallUpgradeVoucher1",
        "WallUpgradeVoucher2",
        "StationUpgradeVoucher1",
        "StationUpgradeVoucher2",
    }
)

ADJACENT_USE_ITEMS = frozenset(
    {
        "WallFixer",
        "WeaponUpgradeVoucher1",
        "WeaponUpgradeVoucher2",
        "WallUpgradeVoucher1",
        "WallUpgradeVoucher2",
        "StationUpgradeVoucher1",
        "StationUpgradeVoucher2",
    }
)

UNTARGETED_USE_ITEMS = frozenset(
    {
        "Medicine",
        "SmallRobotSummonOrder",
        "MiddleRobotSummonOrder",
        "LargeRobotSummonOrder",
        "BossRobotSummonOrder",
    }
)


def is_day_round(round_no: int) -> bool:
    """Return the documented phase for one-based round numbers.

    Round zero or a negative value is treated as the first daytime round. This
    defensive default prevents malformed input from enabling a night-only action.
    """

    safe_round = max(round_no, 1)
    return (safe_round - 1) % ROUNDS_PER_DAY < DAY_ROUNDS


@dataclass(frozen=True, slots=True)
class StrategyConfig:
    normal_turn_budget_seconds: float = NORMAL_TURN_BUDGET_SECONDS
    primary_weapon_loadout: tuple[str, str, str] = (
        ROLE_ROCKET,
        ROLE_ROCKET,
        ROLE_ROCKET,
    )
    comparison_weapon_loadout: tuple[str, str, str] = (
        ROLE_RAILGUN,
        ROLE_RAILGUN,
        ROLE_ROCKET,
    )
    weapon_build_cost: int = WEAPON_BUILD_COST
    max_weapon_count: int = MAX_WEAPON_COUNT
    max_wall_count: int = MAX_WALL_COUNT
    recall_safety_buffer: int = 2
    recall_traffic_buffer: int = 0
    shared_rocket_control: bool = True
    ore_hold_days: int = 2
    final_wall_day: int = 9
    procurement_lead_rounds: int = 35
    night_support_day: int = 3
    robot_attack_range_fallback: int = 3
    base_level_two_day: int = 5
    first_core_wall_day: int = 5
    both_core_walls_day: int = 6
    repair_stock_day: int = 5
    pioneer_repair_stock: int = 6
    surplus_repair_day: int = 6
    surplus_repair_stock: int = 15
    bomb_start_day: int = 5
    opening_raid_day: int = 3
    opening_raid_turns: int = 10
    final_defense_day: int = 10
    final_helper_repairs: int = 5
    bomb_damage: int = 100
    bomb_minimum_medium_kills: int = 2
    allow_surplus_bomb: bool = True
    engineer_stone_reserve: int = 5
    wall_stock_early: int = 5
    worker_medicine_stock: int = 2
    worker_heal_health: int = 140
    escape_search_depth: int = 6
    escape_search_nodes: int = 192
    wall_repair_min_damage: float = 0.30
    wall_heal_fraction: float = 0.40
    wall_retreat_fraction: float = 0.20
    defer_weapon_delivery: bool = True
    second_day_front_upgrades: int = 3
    protect_development_fund: bool = True
    advanced_rocket_day: int = 3
    advanced_wall_day: int = 3
    emergency_gold_reserve: int = 25
    cautious_defense_margin: int = 7
    critical_defense_margin: int = 3
    wall_stone_target: int = 10
    stone_batch_size: int = 10
    initial_wall_target: int = 10
    task_minimum_timeout: int = 4
    task_return_buffer: int = 4
    allow_unverified_night_economy: bool = True
    night_economy_failure_limit: int = 1
    allow_cross_map_fire: bool = False
    allow_summon_pressure: bool = False
    boss_summon_item: str = "BossRobotSummonOrder"
    minimum_opponent_observations: int = 2
    task_command_step_limit: int = 8
    task_command_output_limit: int = 16000
    task_response_wait: int = 3
    task_submit_limit: int = 3
    task_finish_reserve: int = 2
    task_partial_answer_turns: int = 1
    telemetry_byte_budget: int = 2 * 1024 * 1024
    telemetry_reserve_bytes: int = 256 * 1024
    mining_batch_size: int = 10
    mining_minimum_batch: int = 6
    first_night_wall_target: int = 16
    logistics_trip_limit: int = 40
    task_stall_limit: int = 3
    task_expected_rounds: int = 6
    treasure_gold_reserve: int = 125
    treasure_material_gold_cap: int = 300
    market_forecast_weight: float = 1.25


DEFAULT_CONFIG = StrategyConfig()
